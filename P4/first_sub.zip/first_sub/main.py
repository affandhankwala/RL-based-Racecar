from test import test
# Main 
def main ():
    # Load the Track
    directory = "tracks"
    track_name = "L-track"
    test(directory, track_name)
    

    
if __name__ == "__main__": 
    main() 
